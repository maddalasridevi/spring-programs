package com.cg.service;
/*Created By:CH.Saranya
Created On:23/07/2019
purpose:ExceptionMessage Interface to display Error Message for Exceptions

*/

public interface ExceptionMessage {
	String Message1="Check the Data,Failed due to internal server error";

}
