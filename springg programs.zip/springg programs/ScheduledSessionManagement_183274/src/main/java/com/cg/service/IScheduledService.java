package com.cg.service;

import java.util.List;


import com.cg.bean.ScheduleSession;
import com.cg.exception.SessionException;
/*Created By:CH.Saranya
Created On:23/07/2019
purpose:ScheduleService Interface for writting unimplemented methods

*/

public interface IScheduledService {
	List<ScheduleSession> createSession(ScheduleSession scheduleSession) throws SessionException;
	ScheduleSession updateSession(Integer sessionId,Integer duration,String facultyName);
	void deleteSession(Integer sessionId);
	List<ScheduleSession> getAllSessions();
	

}
